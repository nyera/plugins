<?php
if ( ! defined( 'ABSPATH' ) ) exit;
ob_start();
?>
<div class="page active" id="page-settings-tax">
    <div class="page-header">
        <h1>إعدادات الضرائب</h1>
        <p>ضريبة القيمة المضافة والنسب الضريبية</p>
    </div>

    <form id="yamamahSettingsForm" method="post">
        <?php wp_nonce_field( 'yamamah_settings', 'yamamah_settings_nonce' ); ?>
        <div class="card space-y-4">
            <div class="flex justify-between items-center mb-4">
                <span class="text-sm">تفعيل الضريبة</span>
                <label class="toggle-label">
                    <input type="hidden" name="yamamah_tax_enabled" value="no">
                    <input type="checkbox" name="yamamah_tax_enabled" value="yes"
                        <?php checked( $settings['tax_enabled'], 'yes' ); ?>>
                    <div class="toggle <?php echo $settings['tax_enabled'] === 'yes' ? 'on' : ''; ?>"></div>
                </label>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>نسبة الضريبة %</label>
                    <input type="number" class="form-control" name="yamamah_tax_rate"
                           value="<?php echo esc_attr( $settings['tax_rate'] ); ?>">
                </div>
                <div class="form-group">
                    <label>اسم الضريبة</label>
                    <input type="text" class="form-control" value="ضريبة القيمة المضافة" readonly>
                </div>
            </div>
        </div>
        <div class="mt-4">
            <button type="submit" class="btn btn-green">حفظ الإعدادات</button>
            <div id="settingsSaveResult" class="alert alert-success mt-3" style="display:none;">تم الحفظ بنجاح</div>
        </div>
    </form>
</div>
<?php
$page_content = ob_get_clean();
include YAMAMAH_PLUGIN_DIR . 'templates/layout.php';
